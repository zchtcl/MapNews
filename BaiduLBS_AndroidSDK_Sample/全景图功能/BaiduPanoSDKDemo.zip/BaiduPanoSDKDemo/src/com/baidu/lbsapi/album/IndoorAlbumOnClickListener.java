package com.baidu.lbsapi.album;

/**
 * 内景相册点击事件处理
 */
public interface IndoorAlbumOnClickListener {

	/**
	 * 点击相册
	 * @param pid
	 */
	public void onItemClick(String pid);

}
