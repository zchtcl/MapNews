/** Automatically generated file. DO NOT MODIFY */
package com.baidu.baidulocationdemo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}